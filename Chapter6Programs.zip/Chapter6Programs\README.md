# Chapter 6 Programs
Double Lab for [CSCI-0010](https://github.com/nathan-pham/caret-notes)